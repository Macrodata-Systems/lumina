
// Create the popup element
const popup = document.createElement('div');
popup.id = 'lumina-selection-popup';
popup.textContent = '✨ Explain';
popup.style.cssText = `
    position: absolute;
    z-index: 2147483647;
    background: linear-gradient(135deg, #1a1a1a, #2d2d2d);
    color: white;
    padding: 8px 16px;
    border-radius: 50px; /* Pill shape */
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    font-size: 13px;
    font-weight: 600;
    cursor: pointer;
    box-shadow: 0 4px 15px rgba(0,0,0,0.3);
    display: none;
    align-items: center;
    gap: 8px;
    animation: lumina-pop-in 0.25s cubic-bezier(0.175, 0.885, 0.32, 1.275);
    user-select: none;
    transition: transform 0.1s ease, background 0.2s;
    border: 1px solid rgba(255,255,255,0.1);
    white-space: nowrap;
`;

// Add icon
const icon = document.createElement('span');
icon.innerHTML = '✨'; // Simple emoji or SVG
popup.innerHTML = '✨ Explain with Lumina';

document.body.appendChild(popup);

// Add keyframes
const style = document.createElement('style');
style.textContent = `
    @keyframes lumina-pop-in {
        from { opacity: 0; transform: scale(0.8) translateY(5px); }
        to { opacity: 1; transform: scale(1) translateY(0); }
    }
    #lumina-selection-popup:hover {
        transform: scale(1.05);
        background: #2d2d2d !important;
    }
    #lumina-selection-popup:active {
        transform: scale(0.95);
    }
`;
document.head.appendChild(style);

// State
let selectedText = '';

// Handle Selection
document.addEventListener('mouseup', (e) => {
    // Small delay to ensure selection is final
    setTimeout(() => {
        const selection = window.getSelection();
        const text = selection.toString().trim();

        if (text.length > 0) {
            selectedText = text;
            const range = selection.getRangeAt(0);
            const rect = range.getBoundingClientRect();

            // Position calculation
            const scrollX = window.scrollX || window.pageXOffset;
            const scrollY = window.scrollY || window.pageYOffset;

            // Position above the selection
            let top = rect.top + scrollY - 45;
            let left = rect.left + scrollX + (rect.width / 2) - (popup.offsetWidth / 2);

            // Keep within viewport
            if (top < scrollY) top = rect.bottom + scrollY + 10; // Flip to bottom if too high
            if (left < 0) left = 10;

            popup.style.top = `${top}px`;
            popup.style.left = `${left}px`;
            popup.style.display = 'flex';
        } else {
            popup.style.display = 'none';
        }
    }, 10);
});

// Hide on mousedown (starting a new selection)
document.addEventListener('mousedown', (e) => {
    if (e.target !== popup && !popup.contains(e.target)) {
        popup.style.display = 'none';
    }
});

// Handle Click
popup.addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();

    // Send message to background/runtime
    chrome.runtime.sendMessage({
        action: 'explainText',
        text: selectedText
    });

    // Visual feedback
    const originalText = popup.textContent;
    // icon is lost if we overwrite textContent, so finding the text node
    const textNode = Array.from(popup.childNodes).find(node => node.nodeType === Node.TEXT_NODE);
    if (textNode) textNode.textContent = ' Opening...';

    setTimeout(() => {
        popup.style.display = 'none';
        if (textNode) textNode.textContent = '✨ Explain';
    }, 500);
});
